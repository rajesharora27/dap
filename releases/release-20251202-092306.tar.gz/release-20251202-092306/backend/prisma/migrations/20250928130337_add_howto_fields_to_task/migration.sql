-- AlterTable
ALTER TABLE "public"."Task" ADD COLUMN     "howToDoc" TEXT,
ADD COLUMN     "howToVideo" TEXT;

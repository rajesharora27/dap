-- AlterEnum
ALTER TYPE "public"."CustomerTaskStatus" ADD VALUE 'COMPLETED';
